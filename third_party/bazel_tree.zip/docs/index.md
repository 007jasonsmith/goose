Home
====

Skylark is a work-in-progress project, which allows extending Bazel with new
rules or macros (composition of rules and macros).
