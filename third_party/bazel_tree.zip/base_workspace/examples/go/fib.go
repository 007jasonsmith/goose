package main

import (
	"fmt"

	"examples/go/lib1/lib1"
)

func main() {
	fmt.Println("Fib(5):", lib1.Fib(5))
}
